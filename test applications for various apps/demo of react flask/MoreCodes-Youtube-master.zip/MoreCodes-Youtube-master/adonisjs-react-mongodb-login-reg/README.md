# AdonisJS + ReactJS + MongoDB Login and Registration

![ReactJS Todo](../screenshots/react-login1.PNG)
#
![ReactJS Todo](../screenshots/react-login2.PNG)
#
![ReactJS Todo](../screenshots/react-login3.PNG)


## Setup

Manually clone the repo and then run `npm install`.
# AdonisJS + VueJs + MongoDB Todo List

![VueJs Todo](../screenshots/vue-todo.PNG)
#
![VueJs Todo](../screenshots/vue-todo2.PNG)


## Setup

Manually clone the repo and then run `npm install`.
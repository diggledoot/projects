# Flask + Angular + MongoDB Login and Registration

![Angular Todo](../screenshots/vue-login1.PNG)
#
![Angular Todo](../screenshots/vue-login2.PNG)
#
![Angular Todo](../screenshots/vue-login3.PNG)


## Setup

Manually clone the repo and then run `npm install`.
# AdonisJS + ReactJS + MySQL Todo List

![ReactJS Todo](../screenshots/react-todo.PNG)
#
![ReactJS Todo](../screenshots/react-todo2.PNG)


## Setup

Manually clone the repo and then run `npm install`.
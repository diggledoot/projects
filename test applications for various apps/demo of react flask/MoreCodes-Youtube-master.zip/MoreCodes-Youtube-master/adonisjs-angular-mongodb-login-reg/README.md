# AdonisJS + Angular + MongoDB Login and Registration

![Angular Todo](../screenshots/angular-login1.PNG)
#
![Angular Todo](../screenshots/angular-login2.PNG)
#
![Angular Todo](../screenshots/angular-login3.PNG)


## Setup

Manually clone the repo and then run `npm install`.
<template>
  <div class="container">
    <div class="jumbotron mt-5">
      <div class="col-sm-8 mx-auto">
        <h1 class="text-center">WELCOME</h1>
      </div>
    </div>
  </div>
</template>

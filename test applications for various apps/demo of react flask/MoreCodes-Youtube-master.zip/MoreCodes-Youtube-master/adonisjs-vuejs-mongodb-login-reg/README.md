# AdonisJS + VueJS + MongoDB Login and Registration

![VueJS Todo](../screenshots/vue-login1.PNG)
#
![VueJS Todo](../screenshots/vue-login2.PNG)
#
![VueJS Todo](../screenshots/vue-login3.PNG)


## Setup

Manually clone the repo and then run `npm install`.
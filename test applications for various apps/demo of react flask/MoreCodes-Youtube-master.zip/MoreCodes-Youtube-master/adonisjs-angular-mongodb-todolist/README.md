# AdonisJS + Angular + MongoDB Todo List

![Angular Todo](../screenshots/angular-todo.PNG)
#
![Angular Todo](../screenshots/angular-todo2.PNG)


## Setup

Manually clone the repo and then run `npm install`.
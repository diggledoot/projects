export interface Task {
  _id: number
  task_name: string
}
